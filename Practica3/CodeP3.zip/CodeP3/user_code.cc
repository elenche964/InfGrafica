//**************************************************************************
// Codigo del usuario
//
// Domingo Martin Perandres 2013
//
// GPL
//
//Versión: Elena Chaves Hernández, 2019, FEETCE-UGR
//Funciones modificadas: 
//Funciones creadas:set_vertices(...), draw_figure(...), 
//   draw_figure_rev(...), draw_triangles(...), rotar(...)  rev_figure(...)
//Variables creadas: entrada, r, op, NRev, v, vertices, faces
//**************************************************************************

#include "user_code.h"
#include "vertex.h"
#include <math.h>
#include <string.h>
#include <vector>

#ifdef __APPLE__
#include <GLUT/GLUT.h>
#else
#include <GL/glut.h>
#endif
#include <ctype.h>

//Movimientos con parámetros
//Variables globales
vector<double>::const_iterator ptrD; //Iterador para double constante
//Matriz de cizalla de Y sobre X
GLfloat factor=-0.6;
GLfloat cizalla[4][4]={{1,factor,0,0},
	   {0,1,0,0},
	   {0,0,1,0},
	   {0,0,0,1}
	   };
//**************************************************************************
// Funcion para cargar vertices del ply
//**************************************************************************

void set_vertices(const vector<double> &Vertices, vector<_vertex3f> &v)
{
  for (ptrD=Vertices.begin();ptrD!=Vertices.end();ptrD+=3){
     _vertex3f _v = _vertex3f((GLfloat) *ptrD,(GLfloat) *(ptrD+1), (GLfloat) *(ptrD+2));
     v.push_back(_v);
  }
}

//**************************************************************************
// Funcion para dibujar caras del ply
//**************************************************************************

void draw_faces(const vector<unsigned long> &Faces, const vector<_vertex3f> &v){
    glBegin(GL_TRIANGLES);
    for (unsigned i=0; i<Faces.size();i++){
	glVertex3f(v[Faces[i]].x, v[Faces[i]].y, v[Faces[i]].z);
    }
    glEnd();
}

//**************************************************************************
// Funcion para crear la bola
//**************************************************************************
void Bola(){
   glColor3f(0.533,0.541,0.522);
   glutSolidSphere(0.5,20,20); //(double dRadius, GLint slices, GLint stacks)
}

//**************************************************************************
// Funcion para crear rampas en el origen
//**************************************************************************
void Rampa(){

//Base de la rampa
glColor3f(0.757,0.49,0.067);
glPushMatrix();
    glScalef(4, 0.12, 1);
    glutSolidCube(1);
glPopMatrix();

//Lateral 1
glColor3f(0.561, 0.349, 0.008);
glPushMatrix();
    glTranslatef(0, 0.44, -0.56);
    glRotatef(90, 1, 0, 0);
    glScalef(4, 0.12, 1);
    glutSolidCube(1);
glPopMatrix();

//Lateral 2
glPushMatrix();
    glTranslatef(0, 0.44, 0.56);
    glRotatef(90, 1, 0, 0);
    glScalef(4, 0.12, 1);
    glutSolidCube(1);
glPopMatrix();
}

//**************************************************************************
// Funcion para crear la base sin laterales
//**************************************************************************
void Base(const vector<unsigned long> &Faces, const vector<_vertex3f> &v){
glPushMatrix();
	glTranslatef(9,0,0);
	draw_faces(Faces, v);
glPopMatrix();
}

//**************************************************************************
// Funcion para crear la base completa en el origen
//**************************************************************************
void BaseBarrera(){

}

//**************************************************************************
// Funcion para crear la barrera
//**************************************************************************
void Barrera(){
glColor3f(1,0,0);
GLUquadricObj *quadratic;
quadratic = gluNewQuadric();
GLdouble height = 5.0;
glPushMatrix();
    glTranslatef(0, 0, -height/2); //Me crea el objeto con respecto a z
    gluCylinder(quadratic, 0.12, 0.12, height, 20, 20);//(GLUquadric *qobj,GLdouble baseRadius,GLdouble topRadius,GLdouble height,GLint slices,GLint stacks)
glPopMatrix();
}


//**************************************************************************
// Funcion para posicionar la parte fija completa
//**************************************************************************
void Fijo(){
	
	//Rampa();
    //BaseBarrera();
//Inclinada 1
glPushMatrix();
    glTranslatef(0,2*factor,0);
    glRotatef(2,0,1,0);
	glMultMatrixf(*cizalla);
	Rampa();
glPopMatrix();	
	

}

//**************************************************************************
// Funcion para posicionar la bola según tecla
//**************************************************************************
void moverBola(const _vertex3f trans){ //Para ir moviendo la bola al pulsar las teclas(sin terminar), pruebas de movimiento
glPushMatrix();
    glTranslatef(trans.x, trans.y, trans.z);
    Bola();
glPopMatrix();
}

//**************************************************************************
// Funcion para rotar y posicionar la rampa movil según tecla
//**************************************************************************

void RampaMovil(const double &deg){
glPushMatrix();
    glTranslatef(4,0,0);
    glRotatef(90+deg,1,0,0);
    Rampa();
glPopMatrix();
}

//**************************************************************************
// Funcion para posicionar y mover la barrera según tecla
//**************************************************************************
void moverBarrera(const bool opt){ //bool porque la barrera está o para un lado, o para otro

}

//**************************************************************************
// Funcion para dibujar en pantalla
//**************************************************************************
void draw_game(const bool &opt, const double &deg, const _vertex3f trans, const vector<unsigned long> &faces, const vector<_vertex3f> &v){
  Fijo();
  //moverBola(trans);
  //RampaMovil(deg);
  Base(faces, v);
  //moverBarrera(opt);
}

