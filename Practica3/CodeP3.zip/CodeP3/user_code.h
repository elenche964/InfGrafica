//**************************************************************************
// Práctica 2
//
// Domingo Martin Perandres 2013
//
//Versión: Elena Chaves Hernández, 2019, FEETCE-UGR
//Funciones eliminadas: 
//Funciones creadas:set_vertices(...), draw_figure(...), 
//   draw_figure_rev(...), draw_triangles(...), rotar(...)  rev_figure(...)
// GPL
//**************************************************************************

#ifndef USER_CODE_H
#define USER_CODE_H

#include <GL/gl.h>
#include <iterator>
#include <vector>
#include "vertex.h"

using namespace std;

//Lecturas y transformaciones
void set_vertices(const vector<double> &Vertices, vector<_vertex3f> &v);
void draw_faces(const vector<unsigned long> &Faces, const vector<_vertex3f> &v);
GLfloat* CizallaYX(const float factor);

//Objetos
void Bola();
void Rampa();
void Base(const vector<unsigned long> &Faces, const vector<_vertex3f> &v);
void BaseBarrera();
void Barrera();

//Estructuras
void Fijo();
//Estructuras con libertad
void moverBola(const _vertex3f trans);
void RampaMovil(const double &deg);
void moverBarrera(const bool opt);

void draw_game(const bool &opt, const double &deg, const _vertex3f trans,const vector<unsigned long> &Faces, const vector<_vertex3f> &v);

#endif
