//**************************************************************************
// Codigo del usuario
//
// Elena Chaves Hernandez, 2019, FEETCE-UGR
//**************************************************************************

#include "user_code.h"
#include "vertex.h"
#include <math.h>
#include <string.h>
#include <vector>

#ifdef __APPLE__
#include <GLUT/GLUT.h>
#else
#include <GL/glut.h>
#endif
#include <ctype.h>

//Movimientos con parámetros
//Variables globales
vector<double>::const_iterator ptrD; //Iterador para double constante
//Matriz de cizalla de Y sobre X
GLfloat factor=-0.6;
GLfloat cizalla[4][4]={{1,factor,0,0},
	   {0,1,0,0},
	   {0,0,1,0},
	   {0,0,0,1}
	   };
//**************************************************************************
// Funcion para cargar vertices del ply
//**************************************************************************

void set_vertices(const vector<double> &Vertices, vector<_vertex3f> &v)
{
  for (ptrD=Vertices.begin();ptrD!=Vertices.end();ptrD+=3){
     _vertex3f _v = _vertex3f((GLfloat) *ptrD,(GLfloat) *(ptrD+1), (GLfloat) *(ptrD+2));
     v.push_back(_v);
  }
}

//**************************************************************************
// Funcion para dibujar caras del ply
//**************************************************************************

void draw_faces(const vector<unsigned long> &Faces, const vector<_vertex3f> &v){
    glBegin(GL_TRIANGLES);
    for (unsigned i=0; i<Faces.size();i++){
	glVertex3f(v[Faces[i]].x, v[Faces[i]].y, v[Faces[i]].z);
    }
    glEnd();
}

//**************************************************************************
// Funcion para dibujar la bola
//**************************************************************************
void Bola(){
   glColor3f(0.533,0.541,0.522);
   glutSolidSphere(0.5,20,20); //(double dRadius, GLint slices, GLint stacks)
}

//**************************************************************************
// Funcion para dibujar rampas
//**************************************************************************
void Rampa(){

//Base de la rampa
glColor3f(0.757,0.49,0.067);
glPushMatrix();
    glScalef(4, 0.12, 1);
    glutSolidCube(1);
glPopMatrix();

//Lateral 1
glColor3f(0.561, 0.349, 0.008);
glPushMatrix();
    glTranslatef(0, 0.44, -0.56);
    glRotatef(90, 1, 0, 0);
    glScalef(4, 0.12, 1);
    glutSolidCube(1);
glPopMatrix();

//Lateral 2
glPushMatrix();
    glTranslatef(0, 0.44, 0.56);
    glRotatef(90, 1, 0, 0);
    glScalef(4, 0.12, 1);
    glutSolidCube(1);
glPopMatrix();
}

//**************************************************************************
// Funcion para dibujar la base sin laterales
//**************************************************************************
void Base(const vector<unsigned long> &Faces, const vector<_vertex3f> &v){
glPushMatrix();
	glTranslatef(8,0,0);
	draw_faces(Faces, v);
glPopMatrix();
}

//**************************************************************************
// Funcion para crear la base completa
//**************************************************************************
void BaseBarrera(const vector<unsigned long> &Faces, const vector<_vertex3f> &v){
glColor3f(0.757,0.49,0.067);
Base(Faces,v);

//Lateral 1
glColor3f(0.561, 0.349, 0.008);
glPushMatrix();
    glTranslatef(8, 0.44, 0.82);
    glRotatef(-8.0, 0, 1, 0);
    glRotatef(90, 1, 0, 0);
    glScalef(4.0, 0.12, 1);
    glutSolidCube(1);
glPopMatrix();

//Lateral 2
glPushMatrix();
    glTranslatef(8, 0.44, -0.82);
    glRotatef(8.0, 0, 1, 0);
    glRotatef(90, 1, 0, 0);
    glScalef(4.0, 0.12, 1);
    glutSolidCube(1);
glPopMatrix();

//Poste Barra
glPushMatrix();
    glTranslatef(10.55, 0.44, 0);
    glRotatef(90, 0, 1, 0);
    glRotatef(90, 1, 0, 0);
    glScalef(0.24, 0.12, 1);
    glutSolidCube(1);
glPopMatrix();
}

//**************************************************************************
// Funcion para dibujar la barrera segun posicion
//**************************************************************************
void Barrera(const bool pos){
glColor3f(1,0,0);
GLUquadricObj *quadratic;
quadratic = gluNewQuadric();
GLdouble height = 4.0;
int angle=0;
if(pos==true)
    angle=7;
else
    angle=-7;  
glPushMatrix();
    glTranslatef(10.5, 0.12, 0); //Me crea el objeto con respecto a z
    glRotatef(270+angle,0,1,0);
    gluCylinder(quadratic, 0.12, 0.12, height, 20, 20);//(GLUquadric *qobj,GLdouble baseRadius,GLdouble topRadius,GLdouble height,GLint slices,GLint stacks)
glPopMatrix();
}


//**************************************************************************
// Funcion para posicionar la parte fija completa
//**************************************************************************
void Fijo(const vector<unsigned long> &Faces, const vector<_vertex3f> &v){
	
	Rampa();
	
    BaseBarrera(Faces, v);

    //Inclinada 1
    glPointSize(2);
    glColor3f(1,0,0);
    glPushMatrix();
        glTranslatef(12,2*factor,-1.62);
        glRotatef(30,0,1,0);
	    glMultMatrixf(*cizalla);
	    Rampa();
    glPopMatrix();

    //Inclinada 2
    glPushMatrix();
        glTranslatef(12,2*factor,1.62);
        glRotatef(-30,0,1,0);
	    glMultMatrixf(*cizalla);
	    Rampa();
    glPopMatrix();

}

//**************************************************************************
// Funcion para posicionar la bola según tecla
//**************************************************************************
void moverBola(const _vertex3f trans){ //Para ir moviendo la bola al pulsar las teclas(sin terminar), pruebas de movimiento
glPushMatrix();
    glTranslatef(trans.x, trans.y, trans.z);
    Bola();
glPopMatrix();
}

//**************************************************************************
// Funcion para rotar y posicionar la rampa movil según tecla
//**************************************************************************

void RampaMovil(const double &deg){
glPushMatrix();
    glTranslatef(4,0,0);
    glRotatef(90+deg,1,0,0);
    Rampa();
glPopMatrix();
}

//**************************************************************************
// Funcion para dibujar en pantalla
//**************************************************************************
void draw_game(const bool &opt, const double &deg, const _vertex3f trans, const vector<unsigned long> &faces, const vector<_vertex3f> &v){
  Fijo(faces,v);
  moverBola(trans);
  RampaMovil(deg);
  Barrera(opt);
}

