//**************************************************************************
// Práctica 3
//
// Elena Chaves Hernandez, 2019, FEETCE-UGR
//**************************************************************************



using namespace std;

#include <GL/gl.h>
#include <iterator>
#include <vector>
#include "vertex.h"

//Todas usadas de manera interna

//Objetos
void Bola();
void Rampa();
void Base(const vector<unsigned long> &Faces, const vector<_vertex3f> &v);
void BaseBarrera();

//Estructuras
void Fijo();
//Estructuras con libertad
void moverBola(const _vertex3f trans);
void RampaMovil(const double &deg);
void Barrera(const bool pos);

//Funciones usadas en en el programa principal
#ifndef USER_CODE_H
#define USER_CODE_H

//Lecturas y transformaciones
void set_vertices(const vector<double> &Vertices, vector<_vertex3f> &v);
void draw_faces(const vector<unsigned long> &Faces, const vector<_vertex3f> &v);

void draw_game(const bool &opt, const double &deg, const _vertex3f trans,const vector<unsigned long> &Faces, const vector<_vertex3f> &v);

#endif
